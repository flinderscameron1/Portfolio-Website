/**
 * 
 */
/**
 * 
 */
module Task3
{
	requires java.desktop;
}