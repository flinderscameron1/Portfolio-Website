package lab4;
import java.util.*;
public class FishDerbyV2 
{
	public static void main(String[] args) 
	{
		KoocanusaFishDerby derby = new KoocanusaFishDerby();
		
		derby.registerFisherman();
		derby.runDerby();
		
		ArrayList<Fisherman> troutWinners = derby.getTroutWinners();
		ArrayList<Fisherman> salmonWinners = derby.getSalmonWinners();
		
		System.out.println("Trout Results:");

		for(Fisherman f : troutWinners)
		{
			System.out.println("Weight: " + f.getHeaviestTrout().getWeight() + ", " + f.getFirstName() + " " + f.getLastName());
		}
		
		System.out.println("\n Salmon Results:");

		for(Fisherman f : salmonWinners)
		{
			System.out.println("Weight: " + f.getWeightOfTop20HeaviestSalmon() + ", " + f.getFirstName() + " " + f.getLastName());
		}
	}

}
