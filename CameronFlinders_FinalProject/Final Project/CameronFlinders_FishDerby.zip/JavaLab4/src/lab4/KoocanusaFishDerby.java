package lab4;
import java.util.*;
//Create a KoocanusaFishDerby class that has the following:
//Variables/attributes: fishermanList (List), fishDerbyUtil.
//like this: private FishDerbyUtil util = new FishDerbyUtil(214);
//No constructor, just initialize attributes when declared.
//The following methods:
//registerFisherman: takes nothing, adds 330 fisherman to fishermanList using 
//getRandomFisherman method of fishDerbyhUtil, returns nothing.
//runDerby: takes nothing, gets 990 random fish from FishDerbyUtil and gives to a 
//random fisherman using getRandomFishermanId method of FishDerbyUtil. The fishermanId is 
//one more than the index into the list for that fisherman.

//getSalmonWinners: takes nothing, returns a list of the top 3 trout winners 
//(use default sort to sort by getWeightOfTop20HeaviestSalmon method of fisherman.
public class KoocanusaFishDerby
{
	private List<Fisherman> fishermanList = new ArrayList<Fisherman>();
	private FishDerbyUtil util = new FishDerbyUtil();
	
	public void registerFisherman()
	{
		for(int i = 0; i < 330; i++)
		{
			fishermanList.add(util.getRandomFisherman());
		}
	}
	
	public void runDerby()
	{
		for(int i = 0; i < 990; i++)
		{
			Fish fish = util.getRandomFish();
			int fishermanId = util.getRandomFishermanId();
			fishermanList.get(fishermanId - 1).caughtFish(fish);	
		}
	}
	//getTroutWinners: takes nothing, returns a list of the top six trout winners 
	//(use comparator to sort by the heaviest trout weight: getHeaviestTrout.getWeight).
	
	public ArrayList<Fisherman> getTroutWinners()
	{
		ArrayList<Fisherman> troutWinners = new ArrayList<Fisherman>();
		Collections.sort(fishermanList, new Comparator<Fisherman>() {
			public int compare(Fisherman f1, Fisherman f2)
			{
				return -Double.valueOf(f1.getHeaviestTrout().getWeight()).compareTo(f2.getHeaviestTrout().getWeight());
			}
		}
		);
		
		for (int i = 0; i < 6; i++)
		{
			troutWinners.add(fishermanList.get(i));
		}
		
		return troutWinners;
	}
//	 getSalmonWinners: takes nothing, returns a list of the top 3 trout winners (use default sort to sort by
//			 getWeightOfTop20 HeaviestSalmon method of fisherman.
	public ArrayList<Fisherman> getSalmonWinners()
	{
		ArrayList<Fisherman> salmonWinners = new ArrayList<Fisherman>();
		Collections.sort(fishermanList);
		for (int i = 0; i < 3; i++)
		{
			salmonWinners.add(fishermanList.get(i));
		}
		return salmonWinners;
	}
}
