package lab4;

import java.util.ArrayList;

public class Fisherman implements Comparable <Fisherman> 
{
	public int fishermanId;
	public String firstName, lastName;
	public ArrayList<Fish> fishCaught = new ArrayList<>();
	
	public Fisherman(int fishermanId, String lastName, String firstName)
	{
		this.fishermanId = fishermanId;
		this.lastName = lastName;
		this.firstName = firstName;
	}
	
	public int getFishermanId()
	{
		return fishermanId;
	}
	
	public String getFirstName()
	{
		return firstName;
	}
	
	public String getLastName()
	{
		return lastName;
	}
	
	public void caughtFish(Fish fish)
	{
		fishCaught.add(fish);
	}
	
	public Fish getHeaviestTrout()
	{
		Fish heaviestTrout = new Fish("", 0);
		for(Fish fish : fishCaught)
		{
			if(fish.species.toLowerCase().equals("trout"))
			{
				if(fish.weight > heaviestTrout.weight)
				{
					heaviestTrout = fish;
				}
				else
				{
					heaviestTrout.weight = 0;
				}
			}
		}
		return heaviestTrout;
	}
	
	public ArrayList<Fish> getTop20HeaviestSalmon()
	{
		ArrayList<Fish> heaviestSalmon = new ArrayList<>();
		Fish fish = new Fish("salmon", 0);
		heaviestSalmon.add(fish);
		for(Fish fishy : fishCaught)
		{
			if(fishy.species.toLowerCase().equals("salmon"))
			{
				for(int x = 0; x < heaviestSalmon.size(); x++)
				{
					if(heaviestSalmon.get(x).weight < fishy.weight)
					{
						if(heaviestSalmon.size() <= 20)
						{
							heaviestSalmon.add(fishy);
						}
						else
						{
							heaviestSalmon.remove(x);
							heaviestSalmon.add(fishy);
						}
					}
				}
			}
		}
		
		return heaviestSalmon;
	}
	
	public double getWeightOfTop20HeaviestSalmon()
	{
		ArrayList<Fish> heaviestSalmon = getTop20HeaviestSalmon();
		double totalWeight = 0;
		
		for (Fish fish : heaviestSalmon)
		{
			totalWeight += fish.weight;
		}
		
		return totalWeight;
	}
	
	public String toString()
	{
		return "Fisherman Id: " + fishermanId + "\nFisherman name : " + firstName + " " + lastName + "\nHeaviest trout: "
				+ getHeaviestTrout().weight + "\nTotal weight of heaviest 20 salmon: "
				+ getWeightOfTop20HeaviestSalmon();
	}
	@Override
	public int compareTo(Fisherman f) 
	{
		int result = -Double.valueOf(getWeightOfTop20HeaviestSalmon()).compareTo(f.getWeightOfTop20HeaviestSalmon());
		return result;
	}
}

