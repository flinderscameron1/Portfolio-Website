package lab4;

import java.util.Random;

public class FishDerbyUtil
{
	private Random random;
	private String [] fishSpecies = {"Trout","Salmon"};
	private double [] fishSpeciesMaxWeight = {12, 9};
	private int fishermanCount = 0;
	private NameGenerator nameGenerator;
	
	public FishDerbyUtil()
	{
		random = new Random();
		nameGenerator = new NameGenerator();
	}

	public FishDerbyUtil(int randomSeed)
	{
		random = new Random(randomSeed);
		nameGenerator = new NameGenerator(randomSeed);
	}
	
	public Fisherman getRandomFisherman()
	{
		String firstName = nameGenerator.getRandomFirstName();
		String lastName = nameGenerator.getRandomLastName();
		int i = random.nextInt(fishSpeciesMaxWeight.length);
		return new Fisherman(++fishermanCount, firstName, lastName);
	}
	
	public int getRandomFishermanId()
	{
		return random.nextInt(fishermanCount) + 1;
	}
	public Fish getRandomFish()
	{
		int i = random.nextInt(fishSpeciesMaxWeight.length);
		return new Fish(fishSpecies[i], random.nextDouble() * fishSpeciesMaxWeight[i]);
	}

	public static void main(String[] args)
	{
		//FishDerbyUtil util = new FishDerbyUtil();
		FishDerbyUtil util = new FishDerbyUtil(214);  // use specific seed to get same sequence of random numbers
		for(int i = 0; i < 10; i++)
		{
			System.out.println(util.getRandomFish());
		}
		for(int i = 0; i < 10; i++)
		{
			System.out.println(util.getRandomFisherman());
		}
		for(int i = 0; i < 10; i++)
		{
			System.out.println(util.getRandomFishermanId());
		}
	}
}
