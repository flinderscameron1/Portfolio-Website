package lab4;

public class Fish 
{
	public int tagNumber;
	public String species;
	public double weight;
	
	public Fish(int tagNumber, String species, double weight)
	{
		this.tagNumber = tagNumber;
		this.species = species;
		this.weight = weight;
	}
	
	public Fish(String species, double weight)
	{
		this.species = species;
		this.weight = weight;
	}
	
	public int getTagNumber()
	{
		return tagNumber;
	}
	
	public String getSpecies()
	{
		return species;
	}
	
	public double getWeight()
	{
		return weight;
	}
	
	public void setTagNumber(int tagNumber)
	{
		this.tagNumber = tagNumber;
	}
	
	public String toString() 
	{
		return "Tag Number: " + tagNumber + " Species: " + species + " Weight: " + weight;
	}
}

